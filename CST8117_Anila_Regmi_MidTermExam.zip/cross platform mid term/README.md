# Level Selection

## Objective
Using HTML, CSS, and the provided file, create a Level Selection web page that is responsive and closely resembles the design screenshots.
